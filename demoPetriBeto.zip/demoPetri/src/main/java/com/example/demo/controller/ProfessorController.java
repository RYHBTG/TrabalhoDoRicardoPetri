package com.example.demo.controller;

import com.example.demo.service.Professor;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/professores")
public class ProfessorController {

    @Autowired
    Professor professor;

    @GetMapping
    public List<com.example.demo.model.Professor> listarProfessores() {
        return professor.listarProfessores();
    }

    @PostMapping
    public com.example.demo.model.Professor criar(@Valid @RequestBody com.example.demo.model.Professor professor) {
        return this.professor.criar(professor);
    }

    @PutMapping("/{id}")
    public ResponseEntity<?> atualizar(@PathVariable Long id, @RequestBody com.example.demo.model.Professor professor) {
        //return funcionarioService.atualizar(id, funcionario);
        if (this.professor.atualizar(id, professor) == null) {

            String mensagem = "O id informado não existe na base de dados";
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(mensagem);
            //return ResponseEntity.notFound().build();
        }
        return ResponseEntity.ok(professor);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<?> deletar(@PathVariable Long id) {
        if (professor.deletar(id)) {
            String mensagem = "A deleção do id: " + id + " foi realizada com sucesso.";
            return ResponseEntity.status(HttpStatus.ACCEPTED).body(mensagem);
        }
        String mensagem = "O id informado não existe na base de dados";
        return ResponseEntity.status(HttpStatus.NOT_FOUND).body(mensagem);
    }

    @GetMapping("/qtd-professores")
    public int qtdProfessores() {
        return professor.qtdProfessores();
    }

}

