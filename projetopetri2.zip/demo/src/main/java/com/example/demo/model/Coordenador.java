package com.example.demo.model;

import jakarta.persistence.Entity;

@Entity
public class Coordenador extends Professor {
    private int senha;
    private int numFuncGerenciados;

    public Coordenador() {
    }

    public Coordenador(String nome, String cpf, String idade, double salario, int senha, int numFuncGerenciados) {
        super(nome, cpf, idade, salario);
        this.senha = senha;
        this.numFuncGerenciados = numFuncGerenciados;
    }

    public int getSenha() {
        return senha;
    }

    public void setSenha(int senha) {
        this.senha = senha;
    }

    public int getNumFuncGerenciados() {
        return numFuncGerenciados;
    }

    public void setNumFuncGerenciados(int numFuncGerenciados) {
        this.numFuncGerenciados = numFuncGerenciados;
    }
}
