package com.example.demo.service;

import com.example.demo.repository.ProfessorRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class Professor {

    @Autowired
    ProfessorRepository professorRepository;

    public List<com.example.demo.model.Professor> listarProfessores() {
        return professorRepository.findAll();
    }

    public com.example.demo.model.Professor criar(com.example.demo.model.Professor professor) {
        return professorRepository.save(professor);
    }

    public com.example.demo.model.Professor atualizar(Long id, com.example.demo.model.Professor professor) {
        //verificar se o id é valido
        if(professorRepository.existsById(id)) {
            //atualizar o objeto na base
            professor.setId(id);
            return professorRepository.save(professor);
        }
        return null;
        // não realiza nenhuma alteração
    }

    public boolean deletar(Long id) {
        if(professorRepository.existsById(id)) {
            professorRepository.deleteById(id);
            return true;
        }
        return false;
    }

    public int qtdProfessores () {
        return professorRepository.findAll().size();
    }
}