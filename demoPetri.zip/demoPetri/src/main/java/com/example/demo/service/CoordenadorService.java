package com.example.demo.service;

import com.example.demo.model.Coordenador;
import com.example.demo.repository.CoordenadorRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class CoordenadorService {

    @Autowired
    CoordenadorRepository coordenadorRepository;

    public List<Coordenador> listarCoordenador() {
        return coordenadorRepository.findAll();
    }

    public Coordenador criar(Coordenador coordenador) {
        return coordenadorRepository.save(coordenador);
    }

    public Coordenador atualizar(Long id, Coordenador coordenador) {
        if (coordenadorRepository.existsById(id)) {
            coordenador.setId(id);
            return coordenadorRepository.save(coordenador);
        }
        return null;
    }

    public boolean deletar(Long id) {
        if (coordenadorRepository.existsById(id)) {
            coordenadorRepository.deleteById(id);
            return true;
        }
        return false;
    }

    public int qtdCoordenador() {
        return coordenadorRepository.findAll().size();
    }
}
