package com.example.demo.model;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.validation.constraints.NotNull;

import java.util.List;

@Entity
public class Coordenador extends Professor {
    @NotNull(message = "Campo nome não pode ser nulo.")
    private int senha;
    private int numProfGerenciados;

    public Coordenador() {
    }

    public Coordenador(String nome, String cpf, double salario, int senha, int numProfGerenciados) {
        super(nome, cpf, salario);
        this.senha = senha;
        this.numProfGerenciados = numProfGerenciados;
    }

    public int getSenha() {
        return senha;
    }

    public void setSenha(int senha) {
        this.senha = senha;
    }

    public int getnumProfGerenciados() {
        return numProfGerenciados;
    }

    public void setNumProfGerenciados(int numProfGerenciados) {
        this.numProfGerenciados = numProfGerenciados;
    }

    public int getNumProfGerenciados() {
        return numProfGerenciados;
    }

}
