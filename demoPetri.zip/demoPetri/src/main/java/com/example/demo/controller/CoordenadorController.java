package com.example.demo.controller;

import com.example.demo.model.Coordenador;
import com.example.demo.repository.CoordenadorRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/coordenadores")
public class CoordenadorController {

    @Autowired
    CoordenadorRepository coordenadorRepository;

    @GetMapping
    public List<Coordenador> listarCoordenadores() {
        return coordenadorRepository.findAll();
    }

    @PostMapping
    public Coordenador criar(@RequestBody Coordenador coordenador) {
        return coordenadorRepository.save(coordenador);
    }

    @PutMapping("/{id}")
    public ResponseEntity<?> atualizar(@PathVariable Long id, @RequestBody Coordenador coordenador) {
        if (coordenadorRepository.existsById(id)) {
            coordenador.setId(id);
            return ResponseEntity.ok(coordenadorRepository.save(coordenador));
        }
        String mensagem = "O id informado não existe na base de dados";
        return ResponseEntity.status(HttpStatus.NOT_FOUND).body(mensagem);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<?> deletar(@PathVariable Long id) {
        if (coordenadorRepository.existsById(id)) {
            coordenadorRepository.deleteById(id);
            String mensagem = "A deleção do id: " + id + " foi realizada com sucesso.";
            return ResponseEntity.status(HttpStatus.ACCEPTED).body(mensagem);
        }
        String mensagem = "O id informado não existe na base de dados";
        return ResponseEntity.status(HttpStatus.NOT_FOUND).body(mensagem);
    }
}
